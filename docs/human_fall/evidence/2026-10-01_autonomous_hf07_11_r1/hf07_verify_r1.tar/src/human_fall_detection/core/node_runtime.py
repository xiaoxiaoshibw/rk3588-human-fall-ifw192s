"""Pure, ROS-free runtime core for the HF-07 node and HF-11 bridge.

Everything here works on arrays and plain dicts so the whole chain can be tested
on Windows without ROS; ``scripts/human_fall_node.py`` is only message plumbing
around :class:`FallNodeCore`. The core reuses the HF-04..06 modules:

- the HF-01/HF-02 stamp classification and epoch rebuild (``core.timebase``);
- candidate snapshots (``core.lidar_candidates.build_snapshot``);
- the operator selection/ack backend and stance baseline (``core.selection``,
  ``core.baseline``);
- tracking and the rule-based fall state machine (``core.tracking``,
  ``core.features``, ``core.fall_state``).

Composition rules that this layer (not the pure modules) must enforce:

- The **required** cloud input gates everything: an invalid/repeated/expired
  current cloud frame cannot produce a selectable snapshot, and a request that
  arrives while the required input is stale/invalid is rejected even inside the
  snapshot TTL. Release is still allowed so the operator can clear a target.
- The auxiliary IMU/device clock is tracked in a **separate** time base: a
  repeat/reset on the unverified auxiliary stream must not bump the geometry
  cloud epoch or invalidate the operator's selection epoch.
- A select request bound to an older snapshot is accepted only when the
  requested candidate has a **unique continuous match** in the latest valid
  snapshot; a disappeared/ambiguous target is rejected rather than locked from
  a cached position.
- Every observation and baseline sample carries the full binding set
  (session/track/epoch/selection/generation/calibration) so the strict
  ``baseline_applies`` guard can actually succeed without being relaxed.
- Events are JSON-validated before being remembered, so a non-serializable
  event can never poison later state publication; a duplicate (already
  persisted) event is not re-published as new.
"""

import hashlib
import json
import math
import os
import threading
from collections import deque

import numpy as np

try:  # pragma: no cover - import shim exercised through the package/tests
    from core.baseline import StanceBaselineCollector
    from core.calibration import build_geometry_calibration
    from core.fall_state import FallStateMachine
    from core.features import FeatureExtractor
    from core.lidar_candidates import build_snapshot
    from core.selection import SelectionBackend
    from core.timebase import TimebaseSession
    from core.tracking import TargetTracker
except ImportError:  # pragma: no cover
    from baseline import StanceBaselineCollector
    from calibration import build_geometry_calibration
    from fall_state import FallStateMachine
    from features import FeatureExtractor
    from lidar_candidates import build_snapshot
    from selection import SelectionBackend
    from timebase import TimebaseSession
    from tracking import TargetTracker

STATE_KIND = "target_state"
SCHEMA_VERSION = 1
SOURCE_TIME_DOMAIN = "device_stamp_s_unanchored"
METHOD = "lidar_geometry"
INPUT_PROFILE = "lidar_geometry"
MALFORMED_REQUEST = "malformed_request"
REASON_REQUIRED_UNAVAILABLE = "required_cloud_unavailable"
REASON_CANDIDATE_NOT_CURRENT = "candidate_not_current"
CLOCK_DOMAINS = ("monotonic", "message_time")
GATED_ACTIONS = ("select", "capture_baseline")


def finite_or_none(value):
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def dumps_strict(payload):
    return json.dumps(payload, allow_nan=False)


def derive_ground_calibration(ground, fallback_frame="innolidar"):
    """A stable parameter-version record for a standalone (ground-only) config.

    A validated ground without an explicit geometry-calibration artifact still
    needs a non-empty ``calibration_id`` so the strict baseline binding can
    succeed. The id is a content hash of the validated ground, so it is stable
    across runs and only identifies the parameter set; ``reference_frame`` is
    null and every physical verification flag stays false (this does NOT claim
    the extrinsics or the ground physics were verified). Returns ``None`` when
    no valid ground is available or the record cannot be built.
    """
    if not isinstance(ground, dict) or ground.get("status") != "valid":
        return None
    lidar = ground.get("frame") or fallback_frame
    try:
        payload = json.dumps(ground, sort_keys=True, separators=(",", ":"),
                             allow_nan=False)
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
        return build_geometry_calibration(
            "ground-only-" + digest, "unset", lidar, reference_frame=None,
            ground=ground)
    except Exception:  # noqa: BLE001 - a bad artifact must not fabricate a version
        return None


class LatestFrameQueue:
    """Bounded (size-1) latest-frame buffer so callbacks never block on compute."""

    def __init__(self, maxlen=1):
        self._lock = threading.Lock()
        self._items = deque(maxlen=max(1, int(maxlen)))
        self._event = threading.Event()
        self.dropped = 0

    def put(self, item):
        with self._lock:
            if self._items:
                self.dropped += 1
            self._items.append(item)
            self._event.set()

    def take(self):
        with self._lock:
            item = self._items.pop() if self._items else None
            if not self._items:
                self._event.clear()
            return item

    def wait(self, timeout):
        return self._event.wait(timeout)

    def wake(self):
        self._event.set()


class EventLog:
    """Append-only JSONL event store with de-duplication and explicit failure.

    ``append`` returns ``(persisted, reason)``. The event is only remembered
    after it passes ``allow_nan=False`` serialization, so a non-JSON value can
    never be queued into ``recent`` and break later state publication. The event
    is remembered even when the disk write fails (never re-emitted as new), but
    the failure is surfaced as ``degraded`` instead of being reported as a save.
    Loading an existing file on construction means a restarted node never
    replays stored events as fresh ones.
    """

    def __init__(self, path, recent_size=64):
        self.path = path
        self.recent = deque(maxlen=max(1, int(recent_size)))
        self.ids = set()
        self.degraded = False
        self.degrade_reason = None
        self.written = 0
        self._load()

    def _load(self):
        if not self.path or not os.path.isfile(self.path):
            return
        try:
            with open(self.path, encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                    except ValueError:
                        continue
                    event_id = event.get("event_id")
                    if event_id and event_id not in self.ids:
                        self.ids.add(event_id)
                        self.recent.append(event)
                        self.written += 1
        except OSError as exc:
            self.degraded = True
            self.degrade_reason = "event_log_read_failed:{}".format(exc)

    def has(self, event_id):
        return event_id is not None and event_id in self.ids

    def append(self, event):
        event_id = event.get("event_id")
        if event_id is None or event_id in self.ids:
            return False, "duplicate"
        try:
            content = dumps_strict(event)
        except (TypeError, ValueError) as exc:
            self.degraded = True
            self.degrade_reason = "event_log_not_serializable:{}".format(exc)
            return False, self.degrade_reason
        self.ids.add(event_id)
        self.recent.append(event)
        if not self.path:
            self.degraded = True
            self.degrade_reason = "event_log_path_unset"
            return False, self.degrade_reason
        try:
            directory = os.path.dirname(os.path.abspath(self.path))
            if directory:
                os.makedirs(directory, exist_ok=True)
            with open(self.path, "a", encoding="utf-8") as handle:
                handle.write(content + "\n")
            self.written += 1
            return True, None
        except OSError as exc:
            self.degraded = True
            self.degrade_reason = "event_log_write_failed:{}".format(exc)
            return False, self.degrade_reason

    def report(self):
        return {"path": self.path, "degraded": bool(self.degraded),
                "reason": self.degrade_reason, "persisted_count": self.written,
                "recent_count": len(self.recent)}


class FallNodeCore:
    """One-frame-at-a-time geometry/selection/fall runtime (no ROS here)."""

    def __init__(self, session_id, settings=None, ground=None, calibration=None,
                 transform=None, background=None, event_path=None,
                 recent_events=64, expected_frame="innolidar",
                 cloud_timeout_s=0.6, imu_timeout_s=0.3, device_timeout_s=0.6,
                 max_forward_jump_s=30.0, clock_domain="monotonic"):
        sections = settings or {}
        self.session_id = session_id
        self.settings = sections
        self.ground = ground
        if calibration is not None and calibration.get("calibration_id"):
            self.calibration = calibration
        else:
            # Ground-only config: derive a stable parameter version (physical
            # verification flags stay false) so the baseline binding is usable.
            self.calibration = derive_ground_calibration(ground, expected_frame) \
                or calibration
        self.transform = transform
        self.background = background
        self.expected_frame = expected_frame
        self.clock_domain = clock_domain if clock_domain in CLOCK_DOMAINS else "monotonic"
        self._lock = threading.RLock()
        self.tracker = TargetTracker(session_id, sections.get("tracking"))
        self.features = FeatureExtractor(session_id, sections.get("features"))
        self.fall = FallStateMachine(session_id, sections.get("fall"))
        self.baseline = StanceBaselineCollector(session_id, sections.get("baseline"))
        self.selection = SelectionBackend(session_id, self.tracker, self.baseline,
                                          sections.get("selection"))
        self.candidate_settings = sections.get("candidates")
        # Required cloud and auxiliary streams live in separate time bases so an
        # unverified IMU/device clock reset cannot rewind the geometry epoch.
        self.cloud_timebase = TimebaseSession(session_id, self.clock_domain,
                                              max_forward_jump_s=max_forward_jump_s)
        self.cloud_timebase.register("cloud", cloud_timeout_s, required=True)
        self.aux_timebase = TimebaseSession(session_id, self.clock_domain,
                                            max_forward_jump_s=max_forward_jump_s)
        self.aux_timebase.register("imu", imu_timeout_s, required=False)
        self.aux_timebase.register("device", device_timeout_s, required=False)
        self.event_log = EventLog(event_path, recent_events)
        self.imu_quality = {"messages": 0, "finite": None, "last_receive_s": None}
        self.device_quality = {"messages": 0, "last_receive_s": None}
        self._last_candidate = None
        self._last_snapshot_id = None
        self._latest_valid_snapshot = None
        self._baseline_request_id = None
        self._baseline_status = self.baseline.status
        self._last_state = None
        self.frame_count = 0
        self.invalid_frames = 0

    # -- auxiliary stream bookkeeping (never gates the required geometry) ----

    def note_imu(self, receive_s, stamp, frame_id, finite):
        with self._lock:
            self.aux_timebase.note("imu", None, stamp, receive_s, frame_id)
            self.imu_quality["messages"] += 1
            self.imu_quality["finite"] = finite
            self.imu_quality["last_receive_s"] = finite_or_none(receive_s)

    def note_device(self, receive_s, stamp, frame_id):
        with self._lock:
            self.aux_timebase.note("device", None, stamp, receive_s, frame_id)
            self.device_quality["messages"] += 1
            self.device_quality["last_receive_s"] = finite_or_none(receive_s)

    # -- per-frame processing -------------------------------------------------

    def process(self, points, receive_s, *, seq=None, stamp_secs=None,
                stamp_nsecs=None, frame_id=None, now=None):
        """Process one decoded cloud frame; returns snapshot/state/event payloads.

        ``points`` is an ``(N,3)`` array or ``None`` for a frame that could not be
        decoded. ``now`` is the caller's current clock value; it drives freshness
        and the published ``time_received_s``. An invalid stamp or undecodable
        frame yields a diagnostic snapshot but is never registered as a valid,
        selectable snapshot, and its candidates never reach the tracker/fall
        history (the target is reported unobservable/unknown instead).
        """
        now = finite_or_none(now)
        if now is None:
            now = finite_or_none(receive_s) or 0.0
        receive = finite_or_none(receive_s)
        frame = frame_id or self.expected_frame
        with self._lock:
            note = self.cloud_timebase.note("cloud", seq, (stamp_secs, stamp_nsecs),
                                            receive_s, frame)
            if note["epoch_reset"]:
                self.selection.set_epoch(self.cloud_timebase.time_epoch)
            return self._process_locked(points, receive, now, seq, stamp_secs,
                                        stamp_nsecs, frame)

    def _process_locked(self, points, receive, now, seq, stamp_secs, stamp_nsecs,
                        frame):
        stream = self.cloud_timebase.streams["cloud"]
        epoch = self.cloud_timebase.time_epoch
        self.frame_count += 1
        frame_valid = bool(points is not None and stream.stamp_status != "invalid")
        snapshot = None
        candidates = []
        if points is not None:
            snapshot = build_snapshot(
                points, self.candidate_settings, session_id=self.session_id,
                time_epoch=epoch, snapshot_id=self._snapshot_id(seq, receive),
                seq=seq, stamp_secs=stamp_secs, stamp_nsecs=stamp_nsecs,
                source_stamp_s=stream.source_stamp_s, frame_id=frame,
                ground=self.ground, calibration=self.calibration,
                transform=self.transform, background=self.background)
            if frame_valid:
                self.selection.register_snapshot(snapshot, receive if receive is not None else now)
                self._last_snapshot_id = snapshot["snapshot_id"]
                self._latest_valid_snapshot = snapshot
                candidates = snapshot["candidates"]
            else:
                self.invalid_frames += 1
        else:
            self.invalid_frames += 1

        source_stamp_s = stream.source_stamp_s if frame_valid else None
        track_state = self.tracker.update(candidates, epoch,
                                          source_stamp_s=source_stamp_s,
                                          receive_s=receive)
        observed = None
        if frame_valid and track_state["candidate_id"] is not None:
            for candidate in candidates:
                if candidate["candidate_id"] == track_state["candidate_id"]:
                    observed = candidate
                    break
        if observed is not None:
            self._last_candidate = observed
        elif not track_state.get("track_id"):
            # Released/unselected: drop the cached geometry so a later frame
            # cannot keep publishing the previous target's position.
            self._last_candidate = None

        feature_block = self.features.update({
            "candidate": observed,
            "track_id": track_state["track_id"],
            "track_status": track_state["track_status"],
            "position_predicted": track_state["position_predicted"],
            "time_epoch": epoch,
            "session_id": self.session_id,
            "selection_version": track_state["selection_version"],
            "action_generation": track_state["action_generation"],
            "calibration_version": track_state["calibration_version"],
            "source_stamp_s": source_stamp_s,
        }, self.baseline.baseline)

        baseline_ack = self._feed_baseline(observed, track_state, source_stamp_s,
                                           receive, epoch)

        fall_block = self.fall.update(feature_block, {
            "source_stamp_s": source_stamp_s,
            "time_epoch": epoch,
            "session_id": self.session_id,
            "selection_version": track_state["selection_version"],
            "action_generation": track_state["action_generation"],
            "calibration_version": track_state["calibration_version"],
            "track_id": track_state["track_id"],
            "track_status": track_state["track_status"],
        }, self.baseline.baseline)

        new_event = fall_block.get("new_event")
        if new_event is not None:
            persisted, reason = self.event_log.append(new_event)
            if reason == "duplicate":
                new_event = None

        state = self._state_payload(now, snapshot, frame_valid, track_state,
                                    feature_block, fall_block, observed)
        self._last_state = state
        return {"snapshot": snapshot, "state": state, "event": new_event,
                "baseline_ack": baseline_ack}

    def _snapshot_id(self, seq, receive):
        if seq is not None:
            return "seq:{}".format(seq)
        return "recv:{:.6f}".format(receive if receive is not None else 0.0)

    def _feed_baseline(self, observed, track_state, source_stamp_s, receive, epoch):
        if self.baseline.status != "pending":
            return None
        observation = {
            "track_id": track_state["track_id"],
            "calibration_version": track_state["calibration_version"],
            "ground_relative": bool(observed and observed.get("ground_relative_available")),
            "point_count": None if observed is None else observed.get("point_count"),
            "height_m": None if observed is None else observed.get("height_m"),
            "position_m": None if observed is None else observed.get("center_source_m"),
        }
        self.baseline.feed(observation, source_stamp_s=source_stamp_s,
                           predicted=track_state["position_predicted"],
                           occluded=track_state["track_status"] != "locked")
        if self.baseline.status != self._baseline_status:
            previous = self._baseline_status
            self._baseline_status = self.baseline.status
            if previous == "pending" and self.baseline.status in ("ready", "failed"):
                return self._baseline_completion_ack()
        return None

    def _baseline_completion_ack(self):
        status = self.baseline.status
        return {
            "kind": "selection_ack",
            "schema_version": SCHEMA_VERSION,
            "request_id": self._baseline_request_id,
            "action": "capture_baseline",
            "session_id": self.session_id,
            "time_epoch": self.selection.time_epoch,
            "accepted": status == "ready",
            "reason": None if status == "ready" else self.baseline.reason,
            "track_id": self.baseline.track_id,
            "candidate_id": None,
            "selection_version": self.baseline.selection_version,
            "baseline": self.baseline.snapshot(),
            "idempotent_replay": False,
        }

    # -- request handling -----------------------------------------------------

    def _reject(self, request, reason):
        return {
            "kind": "selection_ack", "schema_version": SCHEMA_VERSION,
            "request_id": request.get("request_id"), "action": request.get("action"),
            "session_id": self.session_id, "time_epoch": self.selection.time_epoch,
            "accepted": False, "reason": reason, "track_id": None,
            "candidate_id": None, "selection_version": None, "baseline": None,
            "idempotent_replay": False}

    def _required_input_reason(self, receive_s):
        """Reason the required cloud input is currently unusable, or None."""
        if self._latest_valid_snapshot is None:
            return REASON_REQUIRED_UNAVAILABLE
        stream = self.cloud_timebase.streams["cloud"]
        if stream.stamp_status == "invalid":
            return stream.stamp_reason or "cloud_stamp_invalid"
        status, _age = stream.freshness(receive_s)
        if status != "fresh":
            return "cloud_" + status
        return None

    def _candidate_current(self, request):
        """True when the requested candidate has a unique current match.

        A select bound to an older snapshot is only allowed when the requested
        candidate still matches exactly one candidate in the latest valid
        snapshot (bounded-continuity), so a disappeared or ambiguous person is
        never locked from a cached position.
        """
        latest = self._latest_valid_snapshot
        if latest is None:
            return False, REASON_REQUIRED_UNAVAILABLE
        snapshot_id = request.get("snapshot_id")
        cache = getattr(self.selection, "_snapshots", {})
        entry = cache.get(snapshot_id) if snapshot_id else None
        requested = None
        if entry is not None:
            for candidate in entry["snapshot"].get("candidates", []):
                if candidate.get("candidate_id") == request.get("candidate_id"):
                    requested = candidate
                    break
        if requested is None:
            return True, None  # let the backend report unknown_snapshot/candidate
        if latest.get("snapshot_id") == snapshot_id:
            return True, None
        center = np.asarray(requested.get("center_source_m"), dtype=np.float64)
        gate = float(self.tracker.settings["gate_m"])
        matches = 0
        for candidate in latest.get("candidates", []):
            position = candidate.get("center_source_m")
            if position is None:
                continue
            if float(np.linalg.norm(np.asarray(position, dtype=np.float64) - center)) <= gate:
                matches += 1
        if matches == 1:
            return True, None
        return False, REASON_CANDIDATE_NOT_CURRENT

    def handle_request(self, request, receive_s):
        with self._lock:
            if not isinstance(request, dict):
                return self._reject({"request_id": None, "action": None},
                                    MALFORMED_REQUEST)
            action = request.get("action")
            if action in GATED_ACTIONS:
                reason = self._required_input_reason(receive_s)
                if reason is not None:
                    return self._reject(request, reason)
            if action == "select":
                okay, why = self._candidate_current(request)
                if not okay:
                    return self._reject(request, why)
            ack = self.selection.handle(request, receive_s)
            if (ack.get("accepted") and action == "capture_baseline"
                    and self.baseline.status == "pending"):
                self._baseline_request_id = request.get("request_id")
                self._baseline_status = "pending"
            return ack

    # -- payload assembly -----------------------------------------------------

    def _ground_valid(self):
        return bool(isinstance(self.ground, dict)
                    and self.ground.get("status") == "valid")

    def _observability(self, stream, frame_valid, now):
        status, _age = stream.freshness(now)
        if (not frame_valid or self._latest_valid_snapshot is None
                or stream.stamp_status == "invalid" or status != "fresh"):
            return "invalid"
        if not self._ground_valid():
            return "degraded"
        if self.imu_quality["messages"] and self.imu_quality["finite"] is False:
            return "degraded"
        return "valid"

    def _state_payload(self, now, snapshot, frame_valid, track_state, feature_block,
                       fall_block, observed):
        bbox_min = bbox_max = None
        position_source = None
        position_reference = None
        range_block = None
        bbox_observed = False
        has_target = track_state.get("track_id") is not None
        candidate = observed if observed is not None else \
            (self._last_candidate if has_target else None)
        if candidate is not None:
            bbox_min = candidate.get("bbox_source_min_m")
            bbox_max = candidate.get("bbox_source_max_m")
            position_source = candidate.get("center_source_m")
            position_reference = candidate.get("center_reference_m")
            range_block = candidate.get("range_m")
            bbox_observed = observed is not None
        if not has_target:
            # Released/unselected: no live target position/range/box is claimed.
            bbox_min = bbox_max = None
            position_source = position_reference = range_block = None
            bbox_observed = False
        elif position_source is None:
            position_source = track_state.get("position_m")

        reasons = []
        for code in list(track_state.get("reason_codes") or []) \
                + list(fall_block.get("reason_codes") or []) \
                + self.cloud_timebase.reason_codes(now) \
                + self.aux_timebase.reason_codes(now):
            if code and code not in reasons:
                reasons.append(code)
        if not self._ground_valid() and "ground_unavailable" not in reasons:
            reasons.append("ground_unavailable")

        calibration_id = (self.calibration or {}).get("calibration_id")
        source = None if snapshot is None else snapshot.get("source")
        state = {
            "kind": STATE_KIND,
            "schema_version": SCHEMA_VERSION,
            "session_id": self.session_id,
            "time_epoch": track_state.get("time_epoch"),
            "frame_id": None if source is None else source.get("frame_id"),
            "source_time_domain": SOURCE_TIME_DOMAIN,
            "clock_domain": self.clock_domain,
            "normalized_stamp_s": None,
            "time_received_s": finite_or_none(now),
            "snapshot_id": self._last_snapshot_id,
            "source": source,
            "method": METHOD,
            "input_profile": INPUT_PROFILE,
            "target_kind": "human_like" if track_state.get("track_id") else None,
            "selection_source": "operator" if track_state.get("track_id") else None,
            "observability": self._observability(
                self.cloud_timebase.streams["cloud"], frame_valid, now),
            "reason_codes": reasons,
            "track_id": track_state.get("track_id"),
            "track_status": track_state.get("track_status"),
            "fall_status": fall_block.get("fall_status"),
            "position_source_m": position_source,
            "position_reference_m": position_reference,
            "position_predicted": bool(track_state.get("position_predicted")),
            "prediction_age_s": finite_or_none(track_state.get("prediction_age_s")),
            "prediction_stale": bool(track_state.get("prediction_stale")),
            "velocity_m_s": track_state.get("velocity_m_s"),
            "bbox_source_min_m": bbox_min,
            "bbox_source_max_m": bbox_max,
            "bbox_observed": bbox_observed,
            "range_m": range_block,
            "coordinate": None if snapshot is None else snapshot.get("coordinate"),
            "ground": None if snapshot is None else snapshot.get("ground"),
            "calibration": {
                "calibration_id": calibration_id,
                "ground_status": None if not isinstance(self.ground, dict)
                else self.ground.get("status"),
                "schema_version": (self.calibration or {}).get("schema_version"),
            },
            "selection_version": track_state.get("selection_version"),
            "action_generation": track_state.get("action_generation"),
            "history_reset_reason": fall_block.get("history_reset_reason"),
            "requires_reselection": bool(track_state.get("requires_reselection")),
            "baseline": self.baseline.snapshot(),
            "baseline_version": (self.baseline.baseline or {}).get("baseline_version"),
            "mode_verified": bool(self.fall.settings["mode_verified"]),
            "allow_confirmed": bool(self.fall.settings["allow_confirmed"]),
            "confirmed_enabled": bool(self.fall.confirmed_enabled),
            "sensor_quality": self._sensor_quality(now),
            "event_persistence": self.event_log.report(),
            "recent_events": list(self.event_log.recent),
            "limitations": fall_block.get("limitations"),
            "target_features": feature_block,
            "fall_state": fall_block,
        }
        return state

    def _sensor_quality(self, now):
        quality = {}
        cloud = self.cloud_timebase.streams["cloud"]
        status, age = cloud.freshness(now)
        quality["cloud"] = {"status": status, "age_s": finite_or_none(age),
                            "stamp_status": cloud.stamp_status,
                            "stamp_reason": cloud.stamp_reason,
                            "messages": cloud.messages}
        for label in ("imu", "device"):
            stream = self.aux_timebase.streams[label]
            status, age = stream.freshness(now)
            quality[label] = {"status": status, "age_s": finite_or_none(age),
                              "stamp_status": stream.stamp_status,
                              "stamp_reason": stream.stamp_reason,
                              "messages": stream.messages}
        quality["ground_valid"] = self._ground_valid()
        quality["ground_status"] = None if not isinstance(self.ground, dict) \
            else self.ground.get("status")
        quality["calibration_version"] = (self.calibration or {}).get("calibration_id")
        quality["device_motion"] = "unknown"
        return quality

    def status_state(self, now):
        """A state payload when no new cloud arrived (freshness refresh only).

        The measurement contents are those of the last processed frame; only the
        receive time, freshness and reason codes are recomputed, so a stalled
        stream is reported as stale/invalid instead of holding a green lock.
        """
        now = finite_or_none(now) or 0.0
        with self._lock:
            if self._last_state is None:
                state = self._state_payload(now, None, False,
                                            self.tracker.snapshot(), {}, {}, None)
            else:
                state = dict(self._last_state)
                state["time_received_s"] = finite_or_none(now)
                state["sensor_quality"] = self._sensor_quality(now)
                state["event_persistence"] = self.event_log.report()
                state["recent_events"] = list(self.event_log.recent)
                state["baseline"] = self.baseline.snapshot()
                state["observability"] = self._observability(
                    self.cloud_timebase.streams["cloud"],
                    self._latest_valid_snapshot is not None, now)
                reasons = []
                for code in (self.cloud_timebase.reason_codes(now)
                             + self.aux_timebase.reason_codes(now)
                             + list(state.get("reason_codes") or [])):
                    if code and code not in reasons:
                        reasons.append(code)
                state["reason_codes"] = reasons
            return state
