"""Rigid-body transform and geometry-calibration artifact validation (HF-03).

Scope and honesty rules (see docs/human_fall/tickets/HF-03_geometric_calibration.md):

- A transform ``T_from_to`` maps a point ``p_from`` to ``p_to = R @ p_from + t``.
  Direction, frames and length unit are explicit; a rotation must be a proper
  (orthonormal, ``det=+1``) rigid rotation, so non-rigid matrices and axis-sign
  flips (reflections, ``det=-1``) are rejected before any value is stored.
- A mount translation is checked for plausibility in metres. Supplying a value
  still in millimetres while declaring ``m`` produces an implausible magnitude
  and is reported as ``unit_mismatch_suspected`` instead of being accepted.
- The LiDAR->reference installation transform and the IMU->LiDAR mounting
  rotation are only ever recorded with an explicit evidence source. With no
  on-site measurement they stay ``unknown``; an identity matrix is never
  fabricated just because two frame names match or two topics share a frame_id.
- A single static-scene ground fit never claims a world installation pose or a
  passed calibration: this module stores geometry with an explicit status and a
  separate physical-verification flag that stays false until verified on-site.

This module is pure NumPy + stdlib and is shared by the offline calibration tool
and the regression tests; it never reads ROS, the network or a clock.
"""

import numpy as np

from core.ground import STATUS_VALID, validate_ground_plane

KIND = "geometry_calibration"
SCHEMA_VERSION = 1
UNITS = {"length": "m", "angle": "rad"}
LENGTH_TO_M = {"m": 1.0, "mm": 0.001}
SUPPORTED_LENGTH_UNITS = tuple(sorted(LENGTH_TO_M))
ROTATION_TOLERANCE = 1e-6
MAX_MOUNT_TRANSLATION_M = 50.0
TRANSFORM_STATUSES = ("unknown", "synthetic", "verified")
ROTATION_STATUSES = ("unknown", "synthetic", "verified")
GROUND_STATUSES = ("valid", "orientation_unverified", "invalid")
# Evidence that may back a *real* mount. ``synthetic`` only marks test fixtures
# and can never be promoted to ``verified``.
TRANSFORM_EVIDENCE = ("measured_mount", "survey", "controlled_attitude",
                      "vendor_protocol", "synthetic")
REAL_TRANSFORM_EVIDENCE = tuple(item for item in TRANSFORM_EVIDENCE
                                if item != "synthetic")


class GeometryCalibrationError(ValueError):
    pass


def _numeric_array(values, shape, field):
    if values is None:
        raise GeometryCalibrationError(field + " is required")
    try:
        array = np.asarray(values, dtype=np.float64)
    except (TypeError, ValueError):
        raise GeometryCalibrationError(field + " must be numeric") from None
    if array.shape != shape:
        raise GeometryCalibrationError(
            "{} must have shape {}".format(field, shape))
    if not np.all(np.isfinite(array)):
        raise GeometryCalibrationError(field + " must be finite")
    return array


def validate_rotation(rotation, tolerance=ROTATION_TOLERANCE):
    """Return a validated 3x3 proper rotation, else raise.

    Rejects wrong shape, non-finite entries, non-orthonormal matrices
    (non-rigid / scaled / sheared) and reflections (``det=-1``, an axis-sign
    flip). Only a tolerance-checked orthogonal matrix with ``det=+1`` passes.
    """
    matrix = _numeric_array(rotation, (3, 3), "rotation")
    if abs(float(np.linalg.det(matrix))) < 1e-9:
        raise GeometryCalibrationError("rotation is singular")
    if not np.allclose(matrix @ matrix.T, np.eye(3), atol=float(tolerance)):
        raise GeometryCalibrationError(
            "rotation is not orthonormal (non-rigid matrix)")
    if float(np.linalg.det(matrix)) < 0.0:
        raise GeometryCalibrationError(
            "rotation has negative determinant (axis sign flip)")
    return matrix


def length_to_meters(value, units="m"):
    """Convert a finite length to metres; unknown units raise."""
    if units not in LENGTH_TO_M:
        raise GeometryCalibrationError("unsupported length unit: " + repr(units))
    number = float(value)
    if not np.isfinite(number):
        raise GeometryCalibrationError("length must be finite")
    return number * LENGTH_TO_M[units]


def validate_translation(translation, units="m",
                         max_magnitude_m=MAX_MOUNT_TRANSLATION_M):
    """Return a finite 3-vector in metres, else raise.

    A magnitude beyond ``max_magnitude_m`` (a plausible mount offset) is treated
    as ``unit_mismatch_suspected``: this catches millimetre values declared as
    metres (e.g. a 1.5 m mount entered as ``1500`` with ``units='m'``).
    """
    vector = _numeric_array(translation, (3,), "translation")
    meters = vector * LENGTH_TO_M.get(units, None) if units in LENGTH_TO_M else None
    if meters is None:
        raise GeometryCalibrationError("unsupported length unit: " + repr(units))
    magnitude = float(np.linalg.norm(meters))
    if max_magnitude_m is not None and magnitude > float(max_magnitude_m):
        raise GeometryCalibrationError(
            "unit_mismatch_suspected: translation magnitude {:.3f} m exceeds "
            "the plausible mount bound {:.3f} m".format(magnitude,
                                                        float(max_magnitude_m)))
    return meters


def _check_distinct_frames(from_frame, to_frame):
    for frame in (from_frame, to_frame):
        if not isinstance(frame, str) or not frame:
            raise GeometryCalibrationError("frame names must be non-empty strings")
    if from_frame == to_frame:
        raise GeometryCalibrationError(
            "from_frame and to_frame must differ; a same-name transform is "
            "never assumed to be identity")


def make_unknown_transform(from_frame, to_frame, note=None):
    _check_distinct_frames(from_frame, to_frame)
    return {"kind": "transform", "from_frame": from_frame, "to_frame": to_frame,
            "status": "unknown", "direction": "p_to = R @ p_from + t",
            "rotation": None, "translation_m": None, "units": UNITS["length"],
            "evidence": None, "note": note}


def make_transform(rotation, translation, from_frame, to_frame, units="m",
                   evidence=None, note=None,
                   max_magnitude_m=MAX_MOUNT_TRANSLATION_M):
    """Build a validated transform record with an explicit evidence source.

    Without evidence a numeric transform would be a fabricated mount, so this
    raises; callers that genuinely have no measurement use
    :func:`make_unknown_transform`. A ``synthetic`` transform is a test fixture
    and is certified as ``synthetic``, never ``verified``.
    """
    _check_distinct_frames(from_frame, to_frame)
    if evidence not in TRANSFORM_EVIDENCE:
        raise GeometryCalibrationError(
            "unsupported transform evidence {!r}: a mount transform requires "
            "measured_mount/survey/controlled_attitude/vendor_protocol".format(evidence))
    matrix = validate_rotation(rotation)
    meters = validate_translation(translation, units, max_magnitude_m)
    status = "verified" if evidence in REAL_TRANSFORM_EVIDENCE else "synthetic"
    return {"kind": "transform", "from_frame": from_frame, "to_frame": to_frame,
            "status": status, "direction": "p_to = R @ p_from + t",
            "rotation": matrix.tolist(), "translation_m": meters.tolist(),
            "units": UNITS["length"], "evidence": evidence, "note": note}


def make_rotation(rotation, from_frame, to_frame, evidence=None, note=None):
    """Rotation-only record (e.g. IMU axes into the LiDAR frame)."""
    _check_distinct_frames(from_frame, to_frame)
    if evidence not in TRANSFORM_EVIDENCE:
        raise GeometryCalibrationError(
            "unsupported rotation evidence {!r}: an IMU mounting rotation "
            "requires measured_mount/controlled_attitude/vendor_protocol".format(evidence))
    matrix = validate_rotation(rotation)
    status = "verified" if evidence in REAL_TRANSFORM_EVIDENCE else "synthetic"
    return {"kind": "rotation", "from_frame": from_frame, "to_frame": to_frame,
            "status": status, "rotation": matrix.tolist(),
            "evidence": evidence, "note": note}


def make_unknown_rotation(from_frame, to_frame, note=None):
    _check_distinct_frames(from_frame, to_frame)
    return {"kind": "rotation", "from_frame": from_frame, "to_frame": to_frame,
            "status": "unknown", "rotation": None, "evidence": None, "note": note}


def _load_transform(transform):
    if not isinstance(transform, dict) or transform.get("status") == "unknown":
        raise GeometryCalibrationError("transform is unknown")
    matrix = validate_rotation(transform.get("rotation"))
    meters = _numeric_array(transform.get("translation_m"), (3,), "translation_m")
    return matrix, meters


def invert_transform(transform):
    """Return the inverse transform record (to->from).

    For ``p_to = R p_from + t`` the inverse is ``p_from = R.T p_to - R.T t``.
    The result reuses the same evidence/status, so identity is only ever the
    numerical inverse of a real transform, never an assumed one.
    """
    rotation, translation = _load_transform(transform)
    inverse_rotation = rotation.T
    inverse_translation = -inverse_rotation @ translation
    result = dict(transform)
    result["from_frame"], result["to_frame"] = transform["to_frame"], transform["from_frame"]
    result["rotation"] = inverse_rotation.tolist()
    result["translation_m"] = inverse_translation.tolist()
    return result


def transform_matrix(transform):
    """Homogeneous 4x4 matrix of a transform record."""
    rotation, translation = _load_transform(transform)
    matrix = np.eye(4)
    matrix[:3, :3] = rotation
    matrix[:3, 3] = translation
    return matrix


def apply_transform(points, transform):
    """Apply a transform to an (N,3) point array, returning points in ``to``."""
    try:
        array = np.asarray(points, dtype=np.float64)
    except (TypeError, ValueError):
        raise GeometryCalibrationError("points must be numeric") from None
    if array.ndim != 2 or array.shape[1] != 3 or not np.all(np.isfinite(array)):
        raise GeometryCalibrationError("points must be a finite (N,3) array")
    rotation, translation = _load_transform(transform)
    return array @ rotation.T + translation


def apply_rotation(vectors, rotation_record):
    """Rotate (N,3) vectors by a rotation-only record."""
    array = np.asarray(vectors, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3 or not np.all(np.isfinite(array)):
        raise GeometryCalibrationError("vectors must be a finite (N,3) array")
    if not isinstance(rotation_record, dict) or rotation_record.get("status") == "unknown":
        raise GeometryCalibrationError("rotation is unknown")
    matrix = validate_rotation(rotation_record.get("rotation"))
    return array @ matrix.T


def sensor_height_from_ground(ground):
    """Signed height of the sensor origin above a ground plane, in metres.

    The plane is ``n . p + d = 0`` with ``n`` the unit normal pointing toward
    the sensor (up) and the ground below the origin. The origin's signed
    distance is ``d``; a sensor above its ground has ``d > 0`` and height ``d``.
    A plane at or above the origin, or any non-finite/missing value, stays
    ``None`` instead of guessing.
    """
    if not isinstance(ground, dict) or ground.get("status") != "valid":
        return None
    normal = np.asarray(ground.get("normal"), dtype=np.float64)
    offset = ground.get("offset_m")
    if normal.shape != (3,) or offset is None:
        return None
    if not np.all(np.isfinite(normal)) or not np.isfinite(float(offset)):
        return None
    if normal[2] < 0.0:
        normal = -normal
        offset = -float(offset)
    height = float(offset)
    if height <= 0.0:
        return None
    return height


def validate_geometry_calibration(artifact):
    """Validate and normalise a geometry-calibration artifact.

    Structural checks only; it does not turn an unverified fit into a verified
    one. Unknown transforms/rotations/ground are allowed and preserved, but any
    present numeric record must pass the rigid/unit checks.
    """
    if not isinstance(artifact, dict):
        raise GeometryCalibrationError("artifact must be an object")
    if artifact.get("kind") != KIND:
        raise GeometryCalibrationError("kind must be " + repr(KIND))
    if artifact.get("schema_version") != SCHEMA_VERSION:
        raise GeometryCalibrationError("unsupported schema_version")
    if artifact.get("units") != UNITS:
        raise GeometryCalibrationError("units must be " + repr(UNITS))
    frames = artifact.get("frames")
    if not isinstance(frames, dict) or not frames.get("lidar"):
        raise GeometryCalibrationError("frames.lidar is required")
    for name, record in (artifact.get("transforms") or {}).items():
        if record.get("status") != "unknown":
            recovered = make_transform(record.get("rotation"),
                                       record.get("translation_m"),
                                       record.get("from_frame"),
                                       record.get("to_frame"),
                                       units=record.get("units", "m"),
                                       evidence=record.get("evidence"),
                                       note=record.get("note"))
            if recovered["status"] != record.get("status"):
                raise GeometryCalibrationError("transform status mismatch: " + name)
        else:
            _check_distinct_frames(record.get("from_frame"), record.get("to_frame"))
    for name, record in (artifact.get("rotations") or {}).items():
        if record.get("status") != "unknown":
            recovered = make_rotation(record.get("rotation"), record.get("from_frame"),
                                      record.get("to_frame"),
                                      evidence=record.get("evidence"),
                                      note=record.get("note"))
            if recovered["status"] != record.get("status"):
                raise GeometryCalibrationError("rotation status mismatch: " + name)
        else:
            _check_distinct_frames(record.get("from_frame"), record.get("to_frame"))
    ground = artifact.get("ground")
    if ground is not None:
        try:
            validate_ground_plane(ground, expected_frame=frames["lidar"])
        except ValueError as exc:
            raise GeometryCalibrationError("invalid ground record: " + str(exc)) from None
    verification = artifact.get("verification")
    if not isinstance(verification, dict):
        raise GeometryCalibrationError("verification must be an object")
    transforms = artifact.get("transforms") or {}
    rotations = artifact.get("rotations") or {}
    consistency = (
        ("extrinsics_verified",
         transforms.get("T_reference_lidar", {}).get("status") == "verified"),
        ("imu_alignment_verified",
         rotations.get("R_lidar_imu", {}).get("status") == "verified"),
        ("ground_physical_verified",
         ground is not None and ground.get("status") == STATUS_VALID),
    )
    for flag, satisfied in consistency:
        if verification.get(flag) is True and not satisfied:
            raise GeometryCalibrationError(
                "verification." + flag + " contradicts an unknown/synthetic record")
    statuses = artifact.get("status")
    if not isinstance(statuses, dict):
        raise GeometryCalibrationError("status must be an object")
    if statuses.get("ground") == "valid" and (ground is None
                                              or ground.get("status") != STATUS_VALID):
        raise GeometryCalibrationError("status.ground=valid contradicts the ground record")
    return artifact


def default_statuses():
    return {"extrinsics": "unknown", "imu_alignment": "unknown",
            "ground": "unknown", "geometry_params": "pending"}


def default_verification():
    return {"ground_physical_verified": False, "extrinsics_verified": False,
            "imu_alignment_verified": False}


def build_geometry_calibration(calibration_id, created_at_utc, lidar_frame,
                               reference_frame=None, transforms=None,
                               rotations=None, ground=None, input_info=None,
                               statuses=None, verification=None, note=None):
    """Assemble and validate an independent geometry-calibration artifact.

    ``transforms``/``rotations`` are records built by the ``make_*`` helpers.
    Missing installation transforms and IMU mounting stay explicit ``unknown``
    records, never silent identity matrices.
    """
    if not isinstance(calibration_id, str) or not calibration_id:
        raise GeometryCalibrationError("calibration_id must be a non-empty string")
    if not isinstance(created_at_utc, str) or not created_at_utc:
        raise GeometryCalibrationError("created_at_utc must be a non-empty string")
    if reference_frame is not None:
        _check_distinct_frames(lidar_frame, reference_frame)
    transforms = dict(transforms or {})
    rotations = dict(rotations or {})
    if reference_frame is not None and "T_reference_lidar" not in transforms:
        transforms["T_reference_lidar"] = make_unknown_transform(
            lidar_frame, reference_frame, note="no on-site installation measurement")
    if "R_lidar_imu" not in rotations:
        rotations["R_lidar_imu"] = make_unknown_rotation(
            "imu", lidar_frame, note="no IMU mounting evidence")
    resolved_statuses = default_statuses()
    resolved_statuses.update(statuses or {})
    resolved_verification = default_verification()
    resolved_verification.update(verification or {})
    if ground is not None and ground.get("status") != "valid":
        resolved_statuses["ground"] = "unknown"
    artifact = {
        "kind": KIND,
        "schema_version": SCHEMA_VERSION,
        "calibration_id": calibration_id,
        "created_at_utc": created_at_utc,
        "units": dict(UNITS),
        "frames": {"lidar": lidar_frame, "reference": reference_frame},
        "transforms": transforms,
        "rotations": rotations,
        "ground": ground,
        "sensor_height_m": sensor_height_from_ground(ground) if ground else None,
        "status": resolved_statuses,
        "verification": resolved_verification,
        "input": input_info or {},
        "note": note,
    }
    return validate_geometry_calibration(artifact)
