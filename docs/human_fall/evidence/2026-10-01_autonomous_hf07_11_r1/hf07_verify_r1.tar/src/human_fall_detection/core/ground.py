"""Robust ground-plane fitting and validation in the sensor frame (HF-03).

The fit is deliberately bounded (iteration cap + point cap + fixed seed) and
reports its residual and valid region instead of only a sample error. Failure
modes are explicit:

- too few points -> ``ground_points_insufficient``;
- no dominant plane -> ``ground_not_found``;
- a dominant vertical surface (wall) whose normal is not plausibly "up" ->
  ``ground_orientation_ambiguous`` (horizontal/vertical plane confusion), kept
  as ``orientation_unverified`` rather than reported as ground;
- a dominant plane at or above the origin -> ``ground_above_sensor``;
- a held-out split that is missing, too small, or has too little ground
  support -> ``ground_holdout_insufficient`` / ``ground_holdout_failed``. The
  gate separates two quantities: all-holdout statistics (which include
  legitimate off-plane scene objects such as furniture or a standing person)
  and the independent held-out *ground support* points. Decisive checks are a
  sufficient number of on-ground support points, a support rate coordinated
  with the fit's minimum support gate, and a small on-ground residual. So a
  dominant floor in an ordinary room still passes while a disjoint hold-out
  surface (no ground support) fails. Statistics alone are never a pass.

A plane is ``n . p + d = 0`` with ``n`` a unit normal. The reported normal is
oriented toward the sensor (``n_z >= 0``) and the plane sits below the origin:
the sensor height is the origin's signed distance ``d > 0``. The numerically
heavy step is a thin (``full_matrices=False``) SVD of the inlier covariance, so
memory stays O(N), not O(N^2). A single static-scene fit is a candidate
geometry, never a claim that the world installation pose was verified.
"""

import numpy as np

DEFAULT_SETTINGS = {
    "max_points": 100000,
    "max_fit_points": 50000,
    "range_min_m": 1.0,
    "range_max_m": 30.0,
    "ransac_iterations": 150,
    "inlier_threshold_m": 0.05,
    "min_inliers": 100,
    "min_inlier_fraction": 0.2,
    "normal_up_min_z": 0.5,
    "holdout_fraction": 0.3,
    "min_holdout_points": 20,
    "max_holdout_rms_m": 0.12,
    "min_holdout_support": 0.5,
    "seed": 20261001,
}

STATUS_VALID = "valid"
STATUS_ORIENTATION_UNVERIFIED = "orientation_unverified"
STATUS_INVALID = "invalid"
STATUSES = (STATUS_VALID, STATUS_ORIENTATION_UNVERIFIED, STATUS_INVALID)

REASON_INSUFFICIENT = "ground_points_insufficient"
REASON_NOT_FOUND = "ground_not_found"
REASON_ORIENTATION = "ground_orientation_ambiguous"
REASON_ABOVE_SENSOR = "ground_above_sensor"
REASON_HOLDOUT_INSUFFICIENT = "ground_holdout_insufficient"
REASON_HOLDOUT_FAILED = "ground_holdout_failed"

_REGION_BOUNDS = ("x_min_m", "x_max_m", "y_min_m", "y_max_m", "z_min_m",
                  "z_max_m", "range_min_m", "range_max_m")


def resolve_settings(settings=None):
    """Merge overrides onto the defaults and validate the numeric bounds."""
    resolved = dict(DEFAULT_SETTINGS)
    for key, value in (settings or {}).items():
        if key not in resolved:
            raise ValueError("unknown ground setting: " + str(key))
        resolved[key] = value
    for key in ("max_points", "max_fit_points", "ransac_iterations",
                "min_inliers", "min_holdout_points"):
        resolved[key] = int(resolved[key])
        if resolved[key] <= 0:
            raise ValueError(key + " must be a positive integer")
    for key in ("range_min_m", "range_max_m", "inlier_threshold_m",
                "min_inlier_fraction", "normal_up_min_z", "holdout_fraction",
                "max_holdout_rms_m", "min_holdout_support"):
        resolved[key] = float(resolved[key])
        if not np.isfinite(resolved[key]):
            raise ValueError(key + " must be finite")
    if resolved["range_max_m"] <= resolved["range_min_m"]:
        raise ValueError("range_max_m must be greater than range_min_m")
    if resolved["inlier_threshold_m"] <= 0.0:
        raise ValueError("inlier_threshold_m must be positive")
    if not 0.0 <= resolved["holdout_fraction"] < 1.0:
        raise ValueError("holdout_fraction must be in [0, 1)")
    if not 0.0 <= resolved["normal_up_min_z"] <= 1.0:
        raise ValueError("normal_up_min_z must be between 0 and 1")
    if resolved["max_holdout_rms_m"] <= 0.0:
        raise ValueError("max_holdout_rms_m must be positive")
    if not 0.0 <= resolved["min_holdout_support"] <= 1.0:
        raise ValueError("min_holdout_support must be in [0, 1]")
    return resolved


def _region(points):
    if len(points) == 0:
        return None
    return {"x_min_m": float(points[:, 0].min()), "x_max_m": float(points[:, 0].max()),
            "y_min_m": float(points[:, 1].min()), "y_max_m": float(points[:, 1].max()),
            "z_min_m": float(points[:, 2].min()), "z_max_m": float(points[:, 2].max()),
            "range_min_m": float(np.linalg.norm(points, axis=1).min()),
            "range_max_m": float(np.linalg.norm(points, axis=1).max()),
            "point_count": int(len(points))}


def _residual(plane_normal, offset, points):
    if len(points) == 0:
        return None
    distances = np.abs(points @ plane_normal + offset)
    return {"count": int(len(points)), "rms_m": float(np.sqrt(np.mean(distances ** 2))),
            "max_m": float(distances.max())}


def _support_stats(plane_normal, offset, points, threshold):
    """Ground-support statistics for a point set (unit: metres).

    ``near_ground`` are the points within ``threshold`` of the plane; the
    reported ``rms_m``/``max_m`` are their on-plane residuals. ``fraction`` is
    the near-ground support rate over all supplied points. Non-ground scene
    points (furniture, a standing person) are legitimate off-plane samples and
    are counted in ``fraction`` as non-support, never mistaken for plane error.
    """
    distances = np.abs(points @ plane_normal + offset)
    near = distances <= threshold
    count = int(np.count_nonzero(near))
    if count:
        rms = float(np.sqrt(np.mean(distances[near] ** 2)))
        maximum = float(distances[near].max())
    else:
        rms = maximum = None
    return {"count": count, "rms_m": rms, "max_m": maximum,
            "fraction": float(count / len(points)) if len(points) else None}


def _result(status, reason, settings, point_count, frame, normal=None,
            offset=None, fit_inliers=None, holdout_residual=None,
            inlier_fraction=None, tilt_rad=None):
    valid = status == STATUS_VALID
    height = None
    if normal is not None and offset is not None:
        height = float(offset)
        if height <= 0.0:
            valid = False
            if status == STATUS_VALID:
                status, reason = STATUS_INVALID, REASON_ABOVE_SENSOR
    return {"kind": "ground_plane", "status": status, "valid": valid,
            "reason": reason, "frame": frame, "point_count": int(point_count),
            "normal": None if normal is None else [float(v) for v in normal],
            "offset_m": None if offset is None else float(offset),
            "sensor_height_m": height, "tilt_rad": tilt_rad,
            "fit_inlier_count": None if fit_inliers is None else int(fit_inliers),
            "inlier_fraction": inlier_fraction,
            "holdout_residual": holdout_residual,
            "holdout_support": None,
            "valid_region": None,
            "settings": settings}


def _finish(result, inlier_points, fit_residual_rms, fit_residual_max):
    result["valid_region"] = _region(inlier_points)
    if result["fit_inlier_count"] is not None:
        result["fit_residual"] = {"count": result["fit_inlier_count"],
                                  "rms_m": float(fit_residual_rms),
                                  "max_m": float(fit_residual_max)}
    return result


def _holdout_gate(resolved, normal, offset, holdout, fit_support_threshold):
    """Return (ok, reason, residual, support).

    Validation needs independent held-out ground evidence. ``residual`` keeps
    the all-holdout-point statistics (including legitimate off-plane scene
    objects) for inspection, while ``support`` is the decisive measure: a
    sufficient number of held-out points must lie on the ground with a good
    support rate (coordinated with the fit's minimum support gate) and a small
    on-ground residual. A disjoint hold-out surface gives no ground support and
    still fails; furniture/person points only lower the support rate, they are
    not treated as plane-fit error.
    """
    residual = _residual(normal, offset, holdout)
    support = _support_stats(normal, offset, holdout, resolved["inlier_threshold_m"])
    if len(holdout) < resolved["min_holdout_points"]:
        return False, REASON_HOLDOUT_INSUFFICIENT, residual, support
    support_fraction = max(resolved["min_holdout_support"], fit_support_threshold)
    enough_support = support["count"] >= resolved["min_holdout_points"]
    good_rate = support["fraction"] is not None and support["fraction"] >= support_fraction
    good_points = support["rms_m"] is not None and support["rms_m"] <= resolved["max_holdout_rms_m"]
    if not (enough_support and good_rate and good_points):
        return False, REASON_HOLDOUT_FAILED, residual, support
    return True, None, residual, support


def fit_ground_plane(points, settings=None, frame=None):
    """Fit and validate a ground plane from an (N,3) sensor-frame point array."""
    resolved = resolve_settings(settings)
    array = np.asarray(points, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3:
        raise ValueError("points must be an (N,3) array")
    array = array[np.all(np.isfinite(array), axis=1)]
    if len(array):
        ranges = np.linalg.norm(array, axis=1)
        array = array[(ranges >= resolved["range_min_m"])
                      & (ranges <= resolved["range_max_m"])]
    empty = _result(STATUS_INVALID, REASON_INSUFFICIENT, resolved, len(array), frame)

    if len(array) < max(3, resolved["min_inliers"]):
        return empty
    if len(array) > resolved["max_points"]:
        stride = int(np.ceil(len(array) / resolved["max_points"]))
        array = array[::stride]

    rng = np.random.RandomState(int(resolved["seed"]) % (2 ** 32))
    order = rng.permutation(len(array))
    holdout_count = int(len(array) * resolved["holdout_fraction"])
    holdout = array[order[:holdout_count]] if holdout_count else array[:0]
    fit = array[order[holdout_count:]]
    if len(fit) > resolved["max_fit_points"]:
        fit = fit[::int(np.ceil(len(fit) / resolved["max_fit_points"]))]

    threshold = resolved["inlier_threshold_m"]
    best_count, best_normal, best_offset = -1, None, None
    for _ in range(int(resolved["ransac_iterations"])):
        sample = fit[rng.randint(0, len(fit), 3)]
        normal = np.cross(sample[1] - sample[0], sample[2] - sample[0])
        norm = float(np.linalg.norm(normal))
        if norm < 1e-9:
            continue
        normal = normal / norm
        offset = -float(normal @ sample[0])
        count = int(np.count_nonzero(np.abs(fit @ normal + offset) <= threshold))
        if count > best_count:
            best_count, best_normal, best_offset = count, normal, offset

    if best_normal is None or best_count < resolved["min_inliers"] \
            or best_count < resolved["min_inlier_fraction"] * len(fit):
        return empty

    inliers = fit[np.abs(fit @ best_normal + best_offset) <= threshold]
    centroid = inliers.mean(axis=0)
    # Thin SVD of the (N,3) centred inliers: U is Nx3, so memory stays O(N).
    _, _, vt = np.linalg.svd(inliers - centroid, full_matrices=False)
    normal = vt[-1]
    offset = -float(normal @ centroid)
    if normal[2] < 0.0:
        normal = -normal
        offset = -offset
    tilt = float(np.arccos(np.clip(normal[2], -1.0, 1.0)))

    inlier_distances = np.abs(inliers @ normal + offset)
    inlier_fraction = float(len(inliers) / len(fit))
    fit_rms = float(np.sqrt(np.mean(inlier_distances ** 2)))
    fit_max = float(inlier_distances.max())

    if tilt > np.arccos(resolved["normal_up_min_z"]):
        result = _result(STATUS_ORIENTATION_UNVERIFIED, REASON_ORIENTATION,
                         resolved, len(array), frame, normal, offset,
                         len(inliers), _residual(normal, offset, holdout),
                         inlier_fraction, tilt)
        result["holdout_support"] = _support_stats(normal, offset, holdout,
                                                   threshold)
        return _finish(result, inliers, fit_rms, fit_max)

    ok, reason, residual, support = _holdout_gate(
        resolved, normal, offset, holdout, resolved["min_inlier_fraction"])
    status = STATUS_VALID if ok else STATUS_INVALID
    result = _result(status, reason, resolved, len(array), frame, normal, offset,
                     len(inliers), residual, inlier_fraction, tilt)
    result["holdout_support"] = support
    return _finish(result, inliers, fit_rms, fit_max)


def ground_is_valid(result):
    return bool(isinstance(result, dict) and result.get("status") == STATUS_VALID)


def validate_ground_plane(ground, expected_frame=None, normal_tolerance=1e-3):
    """Strict structural validation of a ground-plane record.

    A ``valid`` ground must carry a unit normal (upward, nearly vertical within
    the reported tilt), a positive height, a well-formed valid region and a
    held-out residual block: statistics alone are not enough, and a record with
    missing/mistyped fields raises instead of being accepted. Non-valid statuses
    may omit the plane but any present normal/offset must still be finite and
    well typed. This never fills in physical values.
    """
    if not isinstance(ground, dict):
        raise ValueError("ground must be an object")
    status = ground.get("status")
    if status not in STATUSES:
        raise ValueError("unsupported ground status: " + repr(status))
    frame = ground.get("frame")
    if not isinstance(frame, str) or not frame:
        raise ValueError("ground.frame must be a non-empty string")
    if expected_frame is not None and frame != expected_frame:
        raise ValueError("ground.frame does not match the artifact lidar frame")
    normal = ground.get("normal")
    offset = ground.get("offset_m")
    if normal is not None:
        array = np.asarray(normal, dtype=np.float64)
        if array.shape != (3,) or not np.all(np.isfinite(array)):
            raise ValueError("ground.normal must be three finite numbers")
    if offset is not None:
        value = float(offset)
        if not np.isfinite(value):
            raise ValueError("ground.offset_m must be finite")
    if status != STATUS_VALID:
        return ground
    if normal is None:
        raise ValueError("a valid ground needs a normal")
    if abs(float(np.linalg.norm(normal)) - 1.0) > float(normal_tolerance):
        raise ValueError("ground normal is not unit length")
    if float(offset) <= 0.0 or normal[2] <= 0.0:
        raise ValueError("a valid ground must sit below the sensor")
    region = ground.get("valid_region")
    if not isinstance(region, dict):
        raise ValueError("a valid ground needs a valid_region")
    for key in _REGION_BOUNDS:
        if key in ("range_min_m", "range_max_m"):
            if region.get(key) is None or not np.isfinite(float(region[key])):
                raise ValueError("valid_region." + key + " must be finite")
        else:
            numeric = region.get(key)
            if numeric is None or not np.isfinite(float(numeric)):
                raise ValueError("valid_region." + key + " must be finite")
    if region["x_min_m"] > region["x_max_m"] or region["y_min_m"] > region["y_max_m"] \
            or region["z_min_m"] > region["z_max_m"] \
            or region["range_min_m"] > region["range_max_m"]:
        raise ValueError("valid_region bounds are inconsistent")
    point_count = region.get("point_count")
    if not isinstance(point_count, int) or isinstance(point_count, bool) \
            or point_count < 0:
        raise ValueError("valid_region.point_count must be a non-negative integer")
    residual = ground.get("holdout_residual")
    if not isinstance(residual, dict) or residual.get("count", 0) <= 0:
        raise ValueError("a valid ground needs a non-empty held-out residual")
    for key in ("rms_m", "max_m"):
        if not np.isfinite(float(residual[key])) or float(residual[key]) < 0.0:
            raise ValueError("holdout_residual." + key + " must be finite and >= 0")
    support = ground.get("holdout_support")
    if not isinstance(support, dict) or support.get("count", 0) <= 0:
        raise ValueError("a valid ground needs held-out ground support")
    fraction = support.get("fraction")
    if fraction is None or not np.isfinite(float(fraction)) \
            or not 0.0 <= float(fraction) <= 1.0:
        raise ValueError("holdout_support.fraction must be in [0, 1]")
    for key in ("rms_m", "max_m"):
        if not np.isfinite(float(support[key])) or float(support[key]) < 0.0:
            raise ValueError("holdout_support." + key + " must be finite and >= 0")
    return ground
