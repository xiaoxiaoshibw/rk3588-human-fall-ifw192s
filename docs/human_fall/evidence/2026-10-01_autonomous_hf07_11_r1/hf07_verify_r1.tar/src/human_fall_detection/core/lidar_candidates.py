"""Posture-independent point-cloud candidates and geometry features (HF-04).

Scope and honesty rules (see docs/human_fall/tickets/HF-04_perception_candidates.md):

- This is geometry only: no camera, no learned human detector, no skeleton. A
  candidate is a connected point cluster with a robust centre, a 3D source-frame
  bounding box, ground-relative height quantiles, a horizontal extent, a PCA
  principal axis (with an explicit degeneracy flag) and the evidence point
  indices back into the decoded cloud. It never claims a semantic human label:
  ``semantic`` stays ``unknown`` until an operator confirms a target (HF-05).
- The old stationary-person size gate (standing height / narrow width-depth) is
  NOT the entry condition here, so a lying or crouching cluster is still kept.
  Low clusters only carry quality flags, they are not dropped for being low.
- Raw LiDAR XY/Z is not assumed to be horizontal/vertical. When the HF-03 ground
  is valid, ground-relative height is ``n . p + d`` and the horizontal plane is
  the ground tangent basis; otherwise the candidate stays in uncalibrated radar
  coordinates with no height/fall observability (never ``ground z = 0``).
- Background is built only from an explicit empty-scene capture and is frozen.
  It is never updated online, so a still person cannot be learned into it.
- Everything here is pure NumPy + stdlib. ROS is touched only in the optional
  ``decode_cloud`` helper, which reuses the existing human_follow decoder.
"""

import numpy as np

try:  # pragma: no cover - import shim exercised through package/tests
    from core.ground import STATUS_VALID
except ImportError:  # pragma: no cover
    from ground import STATUS_VALID

KIND = "candidate_snapshot"
BACKGROUND_KIND = "candidate_background"
SCHEMA_VERSION = 1
UNITS = {"length": "m", "angle": "rad"}

DEFAULT_SETTINGS = {
    "range_min_m": 0.8,
    "range_max_m": 8.0,
    "height_min_m": -0.3,
    "height_max_m": 2.5,
    "voxel_size_m": 0.08,
    "cluster_cell_m": 0.25,
    "max_points": 60000,
    "min_cluster_points": 25,
    "preferred_cluster_points": 80,
    "pca_min_points": 12,
    "pca_axis_ratio": 2.5,
    "background_cell_m": 0.1,
    "background_z_cell_m": 0.1,
}

_POSITIVE = ("range_max_m", "voxel_size_m", "cluster_cell_m", "max_points",
             "min_cluster_points", "preferred_cluster_points", "pca_min_points",
             "pca_axis_ratio", "background_cell_m", "background_z_cell_m")


def resolve_settings(settings=None):
    """Merge overrides onto the defaults and validate the numeric bounds."""
    resolved = dict(DEFAULT_SETTINGS)
    for key, value in (settings or {}).items():
        if key not in resolved:
            raise ValueError("unknown candidate setting: " + str(key))
        resolved[key] = value
    for key in _POSITIVE:
        resolved[key] = float(resolved[key])
        if not np.isfinite(resolved[key]) or resolved[key] <= 0.0:
            raise ValueError(key + " must be a positive finite number")
    resolved["max_points"] = int(resolved["max_points"])
    resolved["min_cluster_points"] = int(resolved["min_cluster_points"])
    resolved["preferred_cluster_points"] = int(resolved["preferred_cluster_points"])
    resolved["pca_min_points"] = int(resolved["pca_min_points"])
    for key in ("range_min_m", "height_min_m", "height_max_m"):
        resolved[key] = float(resolved[key])
        if not np.isfinite(resolved[key]):
            raise ValueError(key + " must be finite")
    if resolved["range_max_m"] <= resolved["range_min_m"]:
        raise ValueError("range_max_m must be greater than range_min_m")
    if resolved["height_max_m"] <= resolved["height_min_m"]:
        raise ValueError("height_max_m must be greater than height_min_m")
    return resolved


def ground_plane_basis(ground):
    """Return (normal, u, v) for a valid ground, else None.

    ``normal`` points up toward the sensor; ``u``/``v`` span the ground tangent
    plane (the physical horizontal plane). An absent/unverified ground returns
    ``None`` so callers fall back to explicit uncalibrated radar coordinates.
    """
    if not isinstance(ground, dict) or ground.get("status") != STATUS_VALID:
        return None
    try:
        normal = np.asarray(ground.get("normal"), dtype=np.float64)
        offset = float(ground.get("offset_m"))
    except (TypeError, ValueError):
        return None
    if normal.shape != (3,) or not np.all(np.isfinite(normal)) or not np.isfinite(offset):
        return None
    norm = float(np.linalg.norm(normal))
    if norm < 1e-9:
        return None
    normal = normal / norm
    reference = np.array([0.0, 0.0, 1.0])
    if abs(float(normal @ reference)) > 0.9:
        reference = np.array([0.0, 1.0, 0.0])
    u = np.cross(normal, reference)
    u = u / np.linalg.norm(u)
    v = np.cross(normal, u)
    return normal, u, v


def _voxel_cells(points, cell_m, z_cell_m):
    grid = np.floor(points / (cell_m, cell_m, z_cell_m)).astype(np.int64)
    return grid


def build_background(empty_frames, settings=None, frame_id=None, note=None):
    """Freeze a static background from explicit empty-scene frames.

    Only the supplied frames are learned; there is deliberately no update call,
    so a still person captured after the empty scene can never drift into the
    background. Cells are source-frame voxels with per-axis cell sizes in metres.
    """
    resolved = resolve_settings(settings)
    arrays = [np.asarray(frame, dtype=np.float64) for frame in empty_frames]
    arrays = [array for array in arrays if array.ndim == 2 and array.shape[1] == 3]
    if not arrays:
        raise ValueError("background needs at least one (N,3) empty-scene frame")
    cells = set()
    point_count = 0
    for array in arrays:
        array = array[np.all(np.isfinite(array), axis=1)]
        if not len(array):
            continue
        point_count += int(len(array))
        grid = _voxel_cells(array, resolved["background_cell_m"],
                            resolved["background_z_cell_m"])
        cells.update(map(tuple, grid.tolist()))
    if not cells:
        raise ValueError("empty-scene frames contain no finite points")
    return {
        "kind": BACKGROUND_KIND,
        "schema_version": SCHEMA_VERSION,
        "units": dict(UNITS),
        "frame_id": frame_id,
        "cell_m": resolved["background_cell_m"],
        "z_cell_m": resolved["background_z_cell_m"],
        "cells": sorted(cells),
        "cell_count": len(cells),
        "frame_count": len(arrays),
        "point_count": point_count,
        "note": note,
    }


def _background_cell_set(background):
    cells = set()
    for cell in background.get("cells", []):
        cells.add((int(cell[0]), int(cell[1]), int(cell[2])))
    return cells


def foreground_mask(points, background):
    """Boolean mask of points not present in a frozen background (True=foreground)."""
    array = np.asarray(points, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3:
        raise ValueError("points must be an (N,3) array")
    if not background:
        return np.ones(len(array), dtype=bool)
    cell_m = float(background.get("cell_m", DEFAULT_SETTINGS["background_cell_m"]))
    z_cell_m = float(background.get("z_cell_m", DEFAULT_SETTINGS["background_z_cell_m"]))
    cells = _background_cell_set(background)
    grid = _voxel_cells(array, cell_m, z_cell_m)
    mask = np.array([tuple(cell) not in cells for cell in grid.tolist()], dtype=bool)
    return mask


def scene_change_fraction(points, background):
    """Fraction of supplied points that are not explained by the frozen background.

    A high fraction indicates the scene moved/changed since the empty capture;
    the caller must then recapture instead of trusting background subtraction.
    Returns ``None`` when no background was supplied.
    """
    if not background:
        return None
    array = np.asarray(points, dtype=np.float64)
    if not len(array):
        return None
    return float(np.count_nonzero(foreground_mask(array, background)) / len(array))


def ground_coverage(points, ground):
    """Fraction of points whose ground projection lies inside the ground region.

    Coverage is judged on the projection onto the ground plane using the fitted
    region's horizontal/range bounds, never by a narrow raw-z band, so a standing
    or lying person is not rejected just for spanning height. No valid ground ->
    ``available`` False with no fraction (never an assumed plane).
    """
    basis = ground_plane_basis(ground)
    if basis is None:
        return {"available": False, "reason": "ground_unavailable",
                "projected_inside_fraction": None, "inside_count": None,
                "point_count": int(len(points))}
    array = np.asarray(points, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3:
        raise ValueError("points must be an (N,3) array")
    if not len(array):
        return {"available": True, "reason": None, "projected_inside_fraction": None,
                "inside_count": 0, "point_count": 0}
    normal, _, _ = basis
    offset = float(ground["offset_m"])
    heights = array @ normal + offset
    projected = array - heights[:, None] * normal
    region = ground.get("valid_region") or {}
    inside = np.ones(len(projected), dtype=bool)
    for axis, prefix in enumerate(("x", "y", "z")):
        low = region.get(prefix + "_min_m")
        high = region.get(prefix + "_max_m")
        if low is not None and high is not None:
            inside &= (projected[:, axis] >= float(low)) & (projected[:, axis] <= float(high))
    ranges = np.linalg.norm(projected, axis=1)
    if region.get("range_min_m") is not None and region.get("range_max_m") is not None:
        inside &= (ranges >= float(region["range_min_m"])) & (ranges <= float(region["range_max_m"]))
    return {"available": True, "reason": None,
            "projected_inside_fraction": float(np.count_nonzero(inside) / len(projected)),
            "inside_count": int(np.count_nonzero(inside)),
            "point_count": int(len(projected))}


def _horizontal_coords(points, basis):
    """Horizontal (u, v) coordinates; raw XY when no valid ground exists."""
    if basis is None:
        return points[:, :2]
    return np.column_stack((points @ basis[1], points @ basis[2]))


def _connected_clusters(horizontal, cell_m):
    """Connected components over occupied horizontal cells (8-neighbourhood)."""
    grid = np.floor(horizontal / float(cell_m)).astype(np.int64)
    buckets = {}
    for index, cell in enumerate(grid.tolist()):
        buckets.setdefault((cell[0], cell[1]), []).append(index)
    seen = set()
    clusters = []
    for start in buckets:
        if start in seen:
            continue
        seen.add(start)
        stack = [start]
        members = []
        while stack:
            current = stack.pop()
            members.extend(buckets[current])
            cx, cy = current
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    neighbour = (cx + dx, cy + dy)
                    if neighbour in buckets and neighbour not in seen:
                        seen.add(neighbour)
                        stack.append(neighbour)
        clusters.append(np.array(members, dtype=np.int64))
    return clusters


def _principal_axis(cluster):
    """PCA principal axis with an explicit degeneracy flag (source frame)."""
    count = len(cluster)
    report = {"axis": None, "eigenvalues": None, "elongation": None,
              "ambiguous": True, "quiet": True}
    if count < 3:
        return report
    centred = cluster - cluster.mean(axis=0)
    covariance = centred.T @ centred / float(count)
    try:
        values, vectors = np.linalg.eigh(covariance)
    except np.linalg.LinAlgError:  # pragma: no cover - defensive
        return report
    order = np.argsort(values)[::-1]
    values = values[order]
    vectors = vectors[:, order]
    largest = float(values[0])
    second = float(values[1])
    elongation = None if second <= 1e-12 else largest / second
    report["eigenvalues"] = [float(value) for value in values]
    report["elongation"] = elongation
    report["quiet"] = False
    report["axis"] = vectors[:, 0].tolist()
    return report


def _robust_span(values):
    if not len(values):
        return None
    low, high = np.percentile(values, [5.0, 95.0])
    return float(high - low)


def _point_features(cluster, basis, ground, settings, source_indices):
    """Geometry feature block for one cluster (all values in metres)."""
    count = int(len(cluster))
    center = np.median(cluster, axis=0)
    bbox_min = cluster.min(axis=0).tolist()
    bbox_max = cluster.max(axis=0).tolist()
    ranges = np.linalg.norm(cluster, axis=1)
    features = {
        "point_count": count,
        "evidence_indices": [int(index) for index in source_indices],
        "center_source_m": [float(value) for value in center],
        "bbox_source_min_m": [float(value) for value in bbox_min],
        "bbox_source_max_m": [float(value) for value in bbox_max],
        "range_m": {"min": float(ranges.min()), "median": float(np.median(ranges)),
                    "max": float(ranges.max())},
        "ground_relative_available": False,
        "height_m": None,
        "height_span_m": None,
        "horizontal_extent_m": None,
        "axis": None,
    }
    if basis is not None:
        normal = basis[0]
        offset = float(ground["offset_m"])
        heights = cluster @ normal + offset
        features["ground_relative_available"] = True
        features["height_m"] = {
            "min": float(heights.min()),
            "p10": float(np.percentile(heights, 10.0)),
            "median": float(np.median(heights)),
            "p90": float(np.percentile(heights, 90.0)),
            "max": float(heights.max()),
        }
        features["height_span_m"] = float(np.percentile(heights, 90.0)
                                          - np.percentile(heights, 10.0))
        u = cluster @ basis[1]
        v = cluster @ basis[2]
        span_u = _robust_span(u)
        span_v = _robust_span(v)
        features["horizontal_extent_m"] = {
            "u": span_u, "v": span_v,
            "max": None if span_u is None or span_v is None else max(span_u, span_v)}
    pca = _principal_axis(cluster)
    axis_report = dict(pca)
    if count < settings["pca_min_points"]:
        axis_report["ambiguous"] = True
        axis_report["reason"] = "insufficient_points"
    elif pca["elongation"] is None or pca["elongation"] < settings["pca_axis_ratio"]:
        axis_report["ambiguous"] = True
        axis_report["reason"] = "no_dominant_axis"
    else:
        axis_report["ambiguous"] = False
        axis_report["reason"] = None
    if pca["axis"] is not None and basis is not None and not axis_report["ambiguous"]:
        axis_report["verticality"] = abs(float(np.asarray(pca["axis"]) @ basis[0]))
    else:
        axis_report["verticality"] = None
    if axis_report["ambiguous"]:
        axis_report["axis"] = None
    features["axis"] = axis_report
    reasons = []
    if count < settings["min_cluster_points"]:
        reasons.append("insufficient_points")
    elif count < settings["preferred_cluster_points"]:
        reasons.append("low_points")
    if axis_report["ambiguous"]:
        reasons.append("axis_ambiguous")
    if basis is None:
        reasons.append("ground_unavailable")
    features["quality"] = {
        "sufficient_points": count >= settings["min_cluster_points"],
        "low_points": count < settings["preferred_cluster_points"],
        "ground_relative": basis is not None,
        "axis_ambiguous": bool(axis_report["ambiguous"]),
        "reasons": reasons,
    }
    return features


def _reference_block(features, transform):
    block = {"center_reference_m": None, "bbox_reference_min_m": None,
             "bbox_reference_max_m": None}
    if not transform or transform.get("status") == "unknown":
        return block
    try:
        from core.calibration import apply_transform
    except ImportError:  # pragma: no cover
        from calibration import apply_transform
    corners = np.array([
        [features["bbox_source_min_m"][0], features["bbox_source_min_m"][1], features["bbox_source_min_m"][2]],
        [features["bbox_source_max_m"][0], features["bbox_source_max_m"][1], features["bbox_source_max_m"][2]],
        [features["center_source_m"]],
    ])
    mapped = apply_transform(corners, transform)
    block["bbox_reference_min_m"] = [float(value) for value in np.minimum(
        mapped[0], mapped[1])]
    block["bbox_reference_max_m"] = [float(value) for value in np.maximum(
        mapped[0], mapped[1])]
    block["center_reference_m"] = [float(value) for value in mapped[2]]
    return block


def build_snapshot(points, settings=None, *, session_id, time_epoch, snapshot_id,
                   seq=None, stamp_secs=None, stamp_nsecs=None,
                   source_stamp_s=None, frame_id="innolidar", ground=None,
                   calibration=None, transform=None, background=None, note=None):
    """Build a versioned candidate snapshot from a decoded (N,3) point array.

    The snapshot is self-describing: session/time_epoch/snapshot_id, the raw
    source seq/sec/nsec it came from, frame and coordinate definitions, the
    calibration version, per-candidate geometry and the evidence indices. IDs
    are only unique inside this snapshot and never claim a tracked person.
    """
    resolved = resolve_settings(settings)
    array = np.asarray(points, dtype=np.float64)
    if array.ndim != 2 or array.shape[1] != 3:
        raise ValueError("points must be an (N,3) array")
    finite = np.all(np.isfinite(array), axis=1)
    array = array[finite]
    original_indices = np.nonzero(finite)[0]
    if len(array) > resolved["max_points"]:
        stride = int(np.ceil(len(array) / resolved["max_points"]))
        array = array[::stride]
        original_indices = original_indices[::stride]

    ranges = np.linalg.norm(array, axis=1) if len(array) else np.zeros(0)
    keep = (ranges >= resolved["range_min_m"]) & (ranges <= resolved["range_max_m"])
    basis = ground_plane_basis(ground)
    if basis is not None and len(array):
        heights = array @ basis[0] + float(ground["offset_m"])
        keep &= (heights >= resolved["height_min_m"]) & (heights <= resolved["height_max_m"])
    array = array[keep]
    original_indices = original_indices[keep]

    if background is not None and len(array):
        fg = foreground_mask(array, background)
        array = array[fg]
        original_indices = original_indices[fg]

    horizontal = _horizontal_coords(array, basis) if len(array) else np.zeros((0, 2))
    clusters = _connected_clusters(horizontal, resolved["cluster_cell_m"]) if len(array) else []

    candidates = []
    for members in clusters:
        cluster_points = array[members]
        cluster_indices = original_indices[members]
        features = _point_features(cluster_points, basis, ground, resolved, cluster_indices)
        if not features["quality"]["sufficient_points"]:
            continue
        features.update(_reference_block(features, transform))
        features["semantic"] = "unknown"
        candidates.append(features)
    candidates.sort(key=lambda item: (round(item["center_source_m"][0], 6),
                                      round(item["center_source_m"][1], 6),
                                      round(item["center_source_m"][2], 6),
                                      item["point_count"]))
    for number, candidate in enumerate(candidates):
        candidate["candidate_id"] = "c{:04d}".format(number)

    coordinate = {
        "source_frame": frame_id,
        "reference_frame": (calibration or {}).get("frames", {}).get("reference")
        if calibration and calibration.get("frames", {}).get("reference") else None,
        "horizontal_basis": "ground_tangent" if basis is not None else "raw_xy_uncalibrated",
        "ground_relative_available": basis is not None,
        "ground_frame": ground.get("frame") if isinstance(ground, dict) else None,
        "transform_status": transform.get("status") if isinstance(transform, dict) else "unknown",
    }
    calibration_block = {
        "calibration_id": (calibration or {}).get("calibration_id"),
        "schema_version": (calibration or {}).get("schema_version"),
        "ground_status": ground.get("status") if isinstance(ground, dict) else "unknown",
    }
    quality = {
        "ground_valid": basis is not None,
        "background_applied": background is not None,
        "candidate_count": len(candidates),
        "input_point_count": int(len(array)),
        "coverage": ground_coverage(array, ground) if len(array) else
        {"available": False, "reason": "no_points", "projected_inside_fraction": None,
         "inside_count": 0, "point_count": 0},
        "reasons": [] if basis is not None else ["ground_unavailable"],
    }
    return {
        "kind": KIND,
        "schema_version": SCHEMA_VERSION,
        "session_id": session_id,
        "time_epoch": int(time_epoch),
        "snapshot_id": snapshot_id,
        "source": {
            "seq": seq,
            "stamp_secs": stamp_secs,
            "stamp_nsecs": stamp_nsecs,
            "source_stamp_s": None if source_stamp_s is None else float(source_stamp_s),
            "frame_id": frame_id,
        },
        "units": dict(UNITS),
        "coordinate": coordinate,
        "calibration": calibration_block,
        "ground": None if not isinstance(ground, dict) else {
            "status": ground.get("status"), "frame": ground.get("frame"),
            "normal": ground.get("normal"), "offset_m": ground.get("offset_m"),
            "sensor_height_m": ground.get("sensor_height_m"),
        },
        "settings": resolved,
        "quality": quality,
        "candidates": candidates,
        "note": note,
    }


def decode_cloud(msg, min_range_m=0.0):
    """Decode a PointCloud2 message to (N,3) using the existing decoder.

    ROS lives only behind this helper; all other functions are array-pure.
    """
    from sensor_health import _load_xyz_from_cloud
    xyz_from_cloud, calibration_error = _load_xyz_from_cloud()
    if xyz_from_cloud is None:
        raise RuntimeError("human_follow_calibration.xyz_from_cloud is unavailable")
    try:
        return xyz_from_cloud(msg, float(min_range_m))
    except calibration_error as exc:  # type: ignore[misc]
        raise ValueError(str(exc)) from exc


def candidates_from_cloud(msg, settings=None, *, min_range_m=0.0, **context):
    """Decode a PointCloud2 message and build a candidate snapshot."""
    return build_snapshot(decode_cloud(msg, min_range_m), settings, **context)


def validate_snapshot(snapshot):
    """Strict structural validation of a candidate snapshot (finite, no NaN)."""
    if not isinstance(snapshot, dict) or snapshot.get("kind") != KIND:
        raise ValueError("snapshot must be a candidate snapshot object")
    if snapshot.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported snapshot schema_version")
    if not isinstance(snapshot.get("session_id"), str) or not snapshot["session_id"]:
        raise ValueError("snapshot.session_id is required")
    if not isinstance(snapshot.get("snapshot_id"), str) or not snapshot["snapshot_id"]:
        raise ValueError("snapshot.snapshot_id is required")
    seen = set()
    for candidate in snapshot.get("candidates", []):
        candidate_id = candidate.get("candidate_id")
        if not isinstance(candidate_id, str) or not candidate_id:
            raise ValueError("candidate_id is required")
        if candidate_id in seen:
            raise ValueError("duplicate candidate_id in snapshot: " + candidate_id)
        seen.add(candidate_id)
        if candidate.get("semantic") != "unknown":
            raise ValueError("candidates stay semantically unknown until operator confirmation")
        for key in ("center_source_m", "bbox_source_min_m", "bbox_source_max_m"):
            values = candidate.get(key)
            if values is None or len(values) != 3 or not np.all(np.isfinite(values)):
                raise ValueError("candidate." + key + " must be three finite numbers")
    return snapshot
