#!/usr/bin/env python3
"""Offline geometry calibration: ground plane from a bag or numeric cloud (HF-03).

This tool is read-only with respect to the live system: it never starts or
restarts the LiDAR, never publishes, and never touches the original bag. It
reads either

- a local numeric point array (``.npy`` or ``.npz`` with a ``points`` array), or
- an existing PointCloud2 bag topic (``rosbag``; only available on the board),

fits a bounded robust ground plane in the sensor frame and writes an
independent geometry-calibration artifact (schema version 1). The installation
transform and the IMU mounting rotation are left explicitly ``unknown``: with no
on-site measurement this tool never fabricates an extrinsic or an identity
matrix, keeps IMU fusion disabled and marks physical verification as not done.
"""

import argparse
import hashlib
import os
import sys
import time
from datetime import datetime, timezone

import numpy as np

PACKAGE_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                           os.pardir))
if PACKAGE_DIR not in sys.path:
    sys.path.insert(0, PACKAGE_DIR)

from core.calibration import (GeometryCalibrationError, build_geometry_calibration)
from core.ground import DEFAULT_SETTINGS, fit_ground_plane, ground_is_valid
from sensor_health import _load_xyz_from_cloud, load_config, save_json


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_points(path):
    """Load a numeric (N,3) array from .npy or .npz (key ``points`` or first)."""
    loaded = np.load(path, allow_pickle=False)
    if isinstance(loaded, np.lib.npyio.NpzFile):
        key = "points" if "points" in loaded.files else loaded.files[0]
        points = loaded[key]
    else:
        points = loaded
    array = np.asarray(points, dtype=np.float64)
    if array.ndim == 2 and array.shape[1] > 3:
        array = array[:, :3]
    if array.ndim != 2 or array.shape[1] != 3:
        raise GeometryCalibrationError(
            "points file must hold an (N,3) array, got shape " + str(array.shape))
    return array


def load_points_from_bag(path, topic, max_frames):
    try:
        import rosbag
    except ImportError as exc:
        raise RuntimeError("rosbag is required for --bag input: " + str(exc))
    xyz_from_cloud, calibration_error = _load_xyz_from_cloud()
    if xyz_from_cloud is None:
        raise RuntimeError("cannot locate human_follow_calibration.xyz_from_cloud")
    chunks = []
    frames = 0
    frame_id = None
    with rosbag.Bag(path, "r") as bag:
        for _, message, _ in bag.read_messages(topics=[topic]):
            if frame_id is None:
                frame_id = getattr(message.header, "frame_id", None)
            try:
                chunks.append(xyz_from_cloud(message, 0.0))
            except calibration_error:
                continue
            frames += 1
            if max_frames and frames >= max_frames:
                break
    if not chunks:
        raise RuntimeError("no decodable PointCloud2 messages on " + topic)
    return np.vstack(chunks), frames, frame_id


def ground_settings(config):
    section = (config or {}).get("ground") or {}
    settings = dict(DEFAULT_SETTINGS)
    settings.update(section)
    return settings


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--points", help="local .npy/.npz numeric cloud")
    source.add_argument("--bag", help="existing rosbag file (read-only)")
    parser.add_argument("--topic", default="/innolidar_points")
    parser.add_argument("--max-frames", type=int, default=0,
                        help="cap decodable bag frames (0 = all)")
    parser.add_argument("--frame", default="innolidar")
    parser.add_argument("--reference-frame", default=None,
                        help="optional reference frame name; transform stays unknown")
    parser.add_argument("--output", required=True)
    parser.add_argument("--config", default=None, help="optional geometry YAML")
    parser.add_argument("--calibration-id", default=None)
    parser.add_argument("--created-at-utc", default=None)
    parser.add_argument("--note", default=None)
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    config = load_config(args.config) if args.config else {}
    settings = ground_settings(config)

    input_info = {"source": "points" if args.points else "bag"}
    if args.points:
        points = load_points(args.points)
        input_info.update({"path": os.path.basename(args.points),
                           "sha256": sha256_file(args.points), "frames": None})
        frame = args.frame
    else:
        points, frames, frame_id = load_points_from_bag(args.bag, args.topic,
                                                        args.max_frames)
        input_info.update({"path": os.path.basename(args.bag), "topic": args.topic,
                           "sha256": sha256_file(args.bag), "frames": frames})
        frame = frame_id or args.frame

    result = fit_ground_plane(points, settings=settings, frame=frame)
    input_info["point_count"] = int(len(points))
    created = args.created_at_utc or datetime.now(timezone.utc).isoformat()
    calibration_id = args.calibration_id or ("geometry_" + time.strftime("%Y%m%d_%H%M%S"))
    valid = ground_is_valid(result)
    artifact = build_geometry_calibration(
        calibration_id, created, frame, reference_frame=args.reference_frame,
        ground=result,
        input_info=input_info,
        statuses={"ground": "valid" if valid else "unknown",
                  "geometry_params": "candidate" if valid else "pending"},
        note=args.note)
    save_json(args.output, artifact)

    summary = {"output": args.output, "status": result["status"],
               "reason": result["reason"], "points": int(len(points)),
               "sensor_height_m": result["sensor_height_m"],
               "tilt_rad": result["tilt_rad"]}
    import json
    print(json.dumps(summary, allow_nan=False))
    return 0 if valid else 2


if __name__ == "__main__":
    sys.exit(main())
