#!/usr/bin/env python3
"""ROS1 node for the HF-04..06 geometry/fall chain (HF-07). Read-only output.

Message plumbing only: the point-cloud callback records the real receive clock
and drops the frame into a bounded latest-frame queue, a single worker thread
decodes and runs the pure :class:`core.node_runtime.FallNodeCore`, and requests
are answered through the same locked core. Nothing here publishes vehicle
commands; the only input topic is operator selection/baseline requests.

Runtime contract exercised by this file:

- bounded queue + single writer, so a slow frame computation never blocks the
  sensor callbacks;
- illegal stamps / undecodable clouds keep an explicit invalid/unknown state
  instead of a fabricated normal scene;
- selection requests are validated by the board-side backend (schema/epoch/
  snapshot/quality/version) and only its ack is authoritative;
- fall events are de-duplicated and appended to a local JSONL log; a write
  failure is surfaced, never reported as a successful save.
"""

import argparse
import json
import os
import threading
import time

SCHEMA_VERSION = 1


def load_yaml(path):
    try:
        import yaml
    except ImportError as exc:  # pragma: no cover - runtime dependency
        raise RuntimeError("PyYAML is required: " + str(exc))
    with open(path, encoding="utf-8") as source:
        return yaml.safe_load(source) or {}


def _resolve_relative(base_dir, path):
    if path is None:
        return None
    if os.path.isabs(path):
        return path
    return os.path.abspath(os.path.join(base_dir, path))


def load_ground_context(config, config_dir):
    """Return (ground, calibration, background) from config paths.

    A configured path that is present but unreadable/invalid raises, so a
    mis-declared calibration never silently degrades to "no ground". No path
    configured is a legitimate waiting state (``ground=None``).
    """
    ground = None
    calibration = None
    background = None
    calibration_path = _resolve_relative(config_dir, config.get("calibration_path"))
    ground_path = _resolve_relative(config_dir, config.get("ground_path"))
    background_path = _resolve_relative(config_dir, config.get("background_path"))
    if calibration_path:
        from core.calibration import validate_geometry_calibration
        with open(calibration_path, encoding="utf-8") as handle:
            artifact = validate_geometry_calibration(json.load(handle))
        calibration = artifact
        ground = artifact.get("ground")
    elif ground_path:
        from core.ground import validate_ground_plane
        with open(ground_path, encoding="utf-8") as handle:
            record = json.load(handle)
        if isinstance(record, dict) and "ground" in record:
            record = record["ground"]
        ground = validate_ground_plane(record) if record is not None else None
    if background_path:
        with open(background_path, encoding="utf-8") as handle:
            background = json.load(handle)
    return ground, calibration, background


def build_core(config, perception, *, session_id, config_dir, event_path):
    from core.node_runtime import FallNodeCore
    topics = config.get("topics", {})
    timeouts = config.get("timeouts_s", {})
    stamps = config.get("stamps", {})
    checks = config.get("checks", {})
    ground, calibration, background = load_ground_context(config.get("geometry", {}),
                                                          config_dir)
    clock_domain = "message_time" if config.get("mode", {}).get("replay") else "monotonic"
    return FallNodeCore(
        session_id, perception, ground=ground, calibration=calibration,
        background=background, event_path=event_path,
        recent_events=int(config.get("output", {}).get("recent_events", 64)),
        expected_frame=checks.get("expected_cloud_frame") or "innolidar",
        cloud_timeout_s=float(timeouts.get("cloud_stale", 0.6)),
        imu_timeout_s=float(timeouts.get("imu_stale", 0.3)),
        device_timeout_s=float(timeouts.get("device_stale", 0.6)),
        max_forward_jump_s=float(stamps.get("max_forward_jump_s", 30.0)),
        clock_domain=clock_domain)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=None,
                        help="node YAML; defaults to the package config/human_fall.yaml")
    parser.add_argument("--perception", default=None,
                        help="perception sections YAML; defaults to config/perception.yaml")
    parser.add_argument("--session-id", default=None)
    parser.add_argument("--output-dir", default=None)
    # Unknown args are ROS remaps/params (e.g. ``_config:=...``); they must not
    # make a standalone or roslaunch invocation fail argument parsing.
    args, _unknown = parser.parse_known_args(argv)
    try:
        import rospy
        import rospkg
        from sensor_msgs.msg import Imu, PointCloud2
        from std_msgs.msg import String
        from inno_lidar_msg.msg import DeviceStatus
    except ImportError as exc:
        parser.exit(2, "ROS1 rospy/rospkg/sensor_msgs/std_msgs/inno_lidar_msg required: {}\n"
                    .format(exc))

    rospy.init_node("human_fall_node", disable_signals=False)
    package_dir = rospkg.RosPack().get_path("human_fall_detection")
    config_path = (rospy.get_param("~config", None) or args.config
                   or os.path.join(package_dir, "config", "human_fall.yaml"))
    config_dir = os.path.dirname(os.path.abspath(config_path))
    config = load_yaml(config_path)
    perception_path = (rospy.get_param("~perception", None) or args.perception
                       or os.path.join(config_dir, "perception.yaml"))
    perception = load_yaml(perception_path)

    session_id = (args.session_id or rospy.get_param("~session_id", "")
                  or config.get("session_id") or "")
    if not session_id:
        session_id = "hfd_" + time.strftime("%Y%m%d_%H%M%S", time.gmtime())

    output = config.get("output", {})
    output_dir = (args.output_dir or rospy.get_param("~output_dir", "")
                  or output.get("session_dir") or "/root/catkin_ws/human_fall_sessions")
    event_path = os.path.join(output_dir, str(output.get("event_file", "events.jsonl")))

    mode = config.get("mode", {})
    require_ground = bool(mode.get("require_ground", False))
    core = build_core(config, perception, session_id=session_id,
                      config_dir=config_dir, event_path=event_path)
    if require_ground and not core._ground_valid():
        parser.exit(3, "no valid ground configured and mode.require_ground is true\n")

    from sensor_health import _load_xyz_from_cloud, dumps_strict, stamp_pair
    xyz_from_cloud, calibration_error = _load_xyz_from_cloud()
    if xyz_from_cloud is None:
        parser.exit(2, "human_follow_calibration.xyz_from_cloud is unavailable; "
                       "the required point-cloud decoder could not be loaded\n")

    topics = config.get("topics", {})
    cloud_topic = topics.get("cloud", "/innolidar_points")
    imu_topic = topics.get("imu", "/inno_imu")
    device_topic = topics.get("device_status", "/device_status")
    publish_period = float(config.get("publish_period_s", 0.5))
    cloud_stale_s = float(config.get("timeouts_s", {}).get("cloud_stale", 0.6))

    publishers = {
        "candidates": rospy.Publisher(topics.get("candidates", "/human_fall/candidates"),
                                      String, queue_size=1),
        "state": rospy.Publisher(topics.get("state", "/human_fall/state"),
                                 String, queue_size=1),
        "event": rospy.Publisher(topics.get("event", "/human_fall/event"),
                                 String, queue_size=4),
        "ack": rospy.Publisher(topics.get("selection_ack", "/human_fall/selection_ack"),
                               String, queue_size=4),
    }

    from core.node_runtime import LatestFrameQueue
    queue = LatestFrameQueue(1)
    stop = threading.Event()

    def on_cloud(msg):
        queue.put((time.monotonic(), msg))

    def on_imu(msg):
        from core.sensor_quality import six_axis_report
        report = six_axis_report(
            (msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z),
            (msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z))
        try:
            core.note_imu(time.monotonic(), stamp_pair(msg.header.stamp),
                          msg.header.frame_id, report["finite"])
        except Exception as exc:  # noqa: BLE001 - auxiliary stream never fatal
            rospy.logwarn_throttle(10.0, "human_fall_node IMU note failed: %s", exc)

    def on_device(msg):
        try:
            core.note_device(time.monotonic(), stamp_pair(msg.header.stamp),
                             msg.header.frame_id)
        except Exception as exc:  # noqa: BLE001
            rospy.logwarn_throttle(10.0, "human_fall_node device note failed: %s", exc)

    def on_request(msg):
        receive_s = time.monotonic()
        try:
            request = json.loads(msg.data)
        except (TypeError, ValueError):
            request = None
        ack = core.handle_request(request, receive_s)
        _publish(publishers["ack"], ack)

    def _publish(publisher, payload):
        try:
            publisher.publish(String(data=dumps_strict(payload)))
        except ValueError as exc:
            rospy.logerr("Refusing non-finite payload on %s: %s", publisher.name, exc)

    rospy.Subscriber(cloud_topic, PointCloud2, on_cloud, queue_size=1,
                     buff_size=2 ** 24)
    rospy.Subscriber(imu_topic, Imu, on_imu, queue_size=64)
    rospy.Subscriber(device_topic, DeviceStatus, on_device, queue_size=8)
    rospy.Subscriber(topics.get("selection_request", "/human_fall/selection_request"),
                     String, on_request, queue_size=16)

    def worker():
        while not stop.is_set():
            got = queue.wait(publish_period)
            item = queue.take() if got else None
            if item is None:
                if stop.is_set():
                    break
                state = core.status_state(time.monotonic())
                _publish(publishers["state"], state)
                continue
            receive_s, msg = item
            now = time.monotonic()
            # A queued frame that is already older than the required-cloud
            # timeout must not be treated as fresh; drop it and only report the
            # current (stale) status. Processing time, not the frame's arrival
            # time, is the online clock for freshness.
            if now - receive_s > cloud_stale_s:
                rospy.logwarn_throttle(5.0, "human_fall_node dropping stale queued frame (%.2fs)",
                                       now - receive_s)
                _publish(publishers["state"], core.status_state(now))
                continue
            points = None
            try:
                points = xyz_from_cloud(msg, 0.0)
            except (ValueError, calibration_error) as exc:  # type: ignore[misc]
                rospy.logwarn_throttle(5.0, "human_fall_node cloud decode failed: %s", exc)
            result = core.process(
                points, receive_s, seq=getattr(msg.header, "seq", None),
                stamp_secs=stamp_pair(msg.header.stamp)[0],
                stamp_nsecs=stamp_pair(msg.header.stamp)[1],
                frame_id=msg.header.frame_id or None, now=now)
            if result["snapshot"] is not None:
                _publish(publishers["candidates"], result["snapshot"])
            _publish(publishers["state"], result["state"])
            if result["event"] is not None:
                _publish(publishers["event"], result["event"])
            if result["baseline_ack"] is not None:
                _publish(publishers["ack"], result["baseline_ack"])

    def shutdown():
        stop.set()
        queue.put(None)
        queue.wake()

    rospy.on_shutdown(shutdown)
    thread = threading.Thread(target=worker, name="human_fall_worker", daemon=True)
    thread.start()
    rospy.loginfo("human_fall_node: %s + %s + %s -> %s (session %s, ground=%s, events=%s)",
                  cloud_topic, imu_topic, device_topic, publishers["state"].name,
                  session_id, "valid" if core._ground_valid() else "unavailable",
                  event_path)
    rate = rospy.Rate(10.0)
    while not rospy.is_shutdown():
        rate.sleep()
    stop.set()
    queue.put(None)
    queue.wake()
    thread.join(timeout=5.0)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
