"""Core helpers for the human-fall work (HF-02 and later tickets).

Pure, ROS-free modules. The frozen HF-01 checks live in ``scripts/sensor_health.py``
and are reused through the path bootstrap below instead of being copied.
"""

import os
import sys

_SCRIPTS_DIR = os.path.abspath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)), os.pardir, "scripts"))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)
